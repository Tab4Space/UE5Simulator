#structure example

import ctypes
import numpy as np
from dataclasses import dataclass

class ActionStruct(ctypes.Structure):
    _fields_ = [
        ("Id", ctypes.c_int32),
        ("Data", ctypes.c_double*3)
    ]
    _pack_ = 1
    
class StateSturcture(ctypes.Structure):
    _fields_ = [
        ("Id", ctypes.c_int32),
        ("Data", ctypes.c_double*3)
    ]
    _pack_ = 1
    
class MessageStructure(ctypes.Structure):
    _fields_ = [
        ("Action", ActionStruct),
        ("State", StateSturcture)
    ]
    _pack_ = 1

@dataclass  
class Custom(ctypes.Structure):
    Action: np.float64 = None
    State: np.int32 = None
    
actionS = ActionStruct()
stateS = StateSturcture()
message = MessageStructure()
message2 = Custom()

print(ctypes.sizeof(actionS))
print(ctypes.sizeof(stateS))
print(ctypes.sizeof(message))
print(ctypes.sizeof(message2))

message.Action.Id = 5

print(message.Action.Id)