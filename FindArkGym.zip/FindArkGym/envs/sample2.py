import win32event
import mmap
import struct
import ctypes
import time

LOADING_SEMAPHORE   = "Global\\FINDARK_LOADING_SEMAPHORE"
UE_SERVER_SEMAPHORE = "Global\\FINDARK_UESERVER_SEMAPHORE"
PY_CLIENT_SEMAPHORE = "Global\\FINDARK_PYCLIENT_SEMAPHORE"


class Message(ctypes.Structure):
    _fields_ = [("Id", ctypes.c_int32),
                ("Data", ctypes.c_double*3)]

memory_pointer = mmap.mmap(-1, 32, "aaa")


def acquire(py_semaphore):
    result = win32event.WaitForSingleObject(py_semaphore, win32event.INFINITE)
    if result == win32event.WAIT_OBJECT_0:
        memory_pointer.seek(0)
        temp = memory_pointer.read(32)
        message= struct.unpack("iddd", temp)
        print(message)
        
        message = Message()
        message.Id = 1
        message.Data[0] = 2.0
        message.Data[1] = 3.0
        message.Data[2] = 4.0
        memory_pointer.seek(0)
        memory_pointer.write(message)
    
def release(ue_semaphore):
    win32event.ReleaseSemaphore(ue_semaphore, 1)


loading_semaphore = win32event.CreateSemaphore(None, 0, 1, LOADING_SEMAPHORE)
win32event.WaitForSingleObject(loading_semaphore, 100000)

ue_semaphore = win32event.OpenSemaphore(win32event.EVENT_ALL_ACCESS, False, UE_SERVER_SEMAPHORE)
py_semaphore = win32event.OpenSemaphore(win32event.EVENT_ALL_ACCESS, False, PY_CLIENT_SEMAPHORE)

acquire(py_semaphore)

step = 0
while True:
    # time.sleep(1)
    step = step + 1
    release(ue_semaphore)
    acquire(py_semaphore)
    print(step)
    # command = input(": ")

    # if command == str(1):
    #     #print("release")
    #     release(ue_semaphore)
        
    #     #print("acquire")
    #     acquire(py_semaphore)

        
    