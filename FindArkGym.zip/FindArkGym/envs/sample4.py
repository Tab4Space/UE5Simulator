import win32event
import mmap
import struct
import ctypes
import time
import numpy as np


my_struct_dtype2 =  np.dtype([
    ("Id", ctypes.c_int32,       ),
    ("Data", ctypes.c_double, (3,)),
    ],
    align = True
)
print(my_struct_dtype2.itemsize)

LOADING_SEMAPHORE   = "Global\\FINDARK_LOADING_SEMAPHORE"
UE_SERVER_SEMAPHORE = "Global\\FINDARK_UESERVER_SEMAPHORE"
PY_CLIENT_SEMAPHORE = "Global\\FINDARK_PYCLIENT_SEMAPHORE"


memory_pointer = mmap.mmap(-1, 32, "FINDARK_SHAREDMEMORY_aaa_action")
memory_pointer2 = mmap.mmap(-1, 32, "FINDARK_SHAREDMEMORY_aaa_state")


def acquire(py_semaphore):
    result = win32event.WaitForSingleObject(py_semaphore, win32event.INFINITE)
    if result == win32event.WAIT_OBJECT_0:
        return 0
        
        
    
def release(ue_semaphore):
    win32event.ReleaseSemaphore(ue_semaphore, 1)
    
def write():
    action = np.array([(1, (1.1, 1.2, 1.3))], dtype=my_struct_dtype2).tobytes()
    memory_pointer.seek(0)
    memory_pointer.write(action)
    
    
def read():
    memory_pointer2.seek(0)
    result = memory_pointer2.read(32)
    result = np.frombuffer(result, dtype=my_struct_dtype2)
    print(result)

    

loading_semaphore = win32event.CreateSemaphore(None, 0, 1, LOADING_SEMAPHORE)
win32event.WaitForSingleObject(loading_semaphore, 100000)

ue_semaphore = win32event.OpenSemaphore(win32event.EVENT_ALL_ACCESS, False, UE_SERVER_SEMAPHORE)
py_semaphore = win32event.OpenSemaphore(win32event.EVENT_ALL_ACCESS, False, PY_CLIENT_SEMAPHORE)

release(ue_semaphore)
read()
acquire(py_semaphore)

step = 1
while True:
    time.sleep(1)
    step = step + 1
    write()
    release(ue_semaphore)
    acquire(py_semaphore)
    read()
    print(step)